# BaseAds Library - DEBUG VERSION

**⚠️ DEBUG BUILD - NOT FOR PRODUCTION ⚠️**

**Version:** 1.0.0  
**Version Code:**   
**Built:** Wed Nov 12 19:50:44 +07 2025  
**File:** base-ads-debug-v1.0.0-20251112_195034.aar  
**Size:** 184K  
**Type:** DEBUG with full logging

## 🐛 Debug Features

- ✅ **Full logging enabled** - All AdsLogger.d(), .i(), .w(), .e() messages
- ✅ **Debug symbols included** - Better crash reports
- ✅ **No code obfuscation** - Easier debugging
- ✅ **Source line numbers** - Accurate stack traces
- ✅ **All analytics events logged** - See every interaction

## 📦 What's Included

- ✅ Google Mobile Ads SDK integration
- ✅ ironSource mediation support  
- ✅ Firebase Analytics integration
- ✅ Adaptive banner ads with preloading
- ✅ Interstitial ads with smart timing
- ✅ VIP user management
- ✅ Force update functionality
- ✅ Jetpack Compose UI components
- ✅ Hilt dependency injection ready
- 🐛 **FULL DEBUG LOGGING**

## 🚀 Integration Guide

### 1. Copy files to your project
```bash
YourProject/
├── app/
│   ├── libs/
│   │   ├── base-ads-debug-v1.0.0-20251112_195034.aar                    # Main library
│   │   └── base-ads-debug-v1.0.0-sources.jar # Sources for debugging
│   └── build.gradle.kts
```

### 2. Add dependencies to app/build.gradle.kts
```kotlin
dependencies {
    // BaseAds DEBUG Library
    implementation(files("libs/base-ads-debug-v1.0.0-20251112_195034.aar"))
    
    // REQUIRED: Add mediation adapters manually (files() doesn't resolve transitive deps)
    implementation("com.google.android.gms:play-services-ads:24.6.0")
    implementation("com.google.ads.mediation:vungle:7.4.0.0")           // LiftOff
    implementation("com.google.ads.mediation:ironsource:8.4.0.0")       // IronSource  
    implementation("com.google.ads.mediation:facebook:6.17.0.0")        // Meta
    
    // Firebase
    implementation(platform("com.google.firebase:firebase-bom:33.5.1"))
    implementation("com.google.firebase:firebase-analytics-ktx")
    implementation("com.google.firebase:firebase-config-ktx")
    
    // Compose BOM
    implementation(platform("androidx.compose:compose-bom:2024.02.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    
    // Hilt
    implementation("com.google.dagger:hilt-android:2.48")
    ksp("com.google.dagger:hilt-compiler:2.48")
}
```

### 3. Attach sources for debugging (Android Studio)

**Option A: Automatic (Recommended)**
1. Open project in Android Studio
2. Sync Gradle
3. Sources JAR will be auto-detected in `libs/` folder

**Option B: Manual attach**
1. Navigate to **External Libraries** → Find `base-ads-debug`
2. Right-click → **Library Properties**
3. Click **+** → Select `base-ads-debug-*-sources.jar`
4. Click **OK**

Now you can:
- ✅ **Ctrl+Click** to jump into BaseAds source code
- ✅ Set **breakpoints** inside library code
- ✅ See **variable names** (not obfuscated)
- ✅ Full **stack traces** with line numbers

### 4. Enable logging in your app
```kotlin
// In your Application class
class YourApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        
        // Enable debug logging
        AdsLogger.setLogLevel(AdsLogger.LogLevel.DEBUG)
    }
}
```

## 🐛 Debug Logging

This DEBUG version will show detailed logs for:

### Banner Ads
```
D/BaseAds-Banner: Preloading banner ad...
D/BaseAds-Banner: Banner ad loaded successfully
D/BaseAds-Banner: Showing preloaded banner
```

### Interstitial Ads  
```
D/BaseAds-Interstitial: Loading interstitial ad...
D/BaseAds-Interstitial: maybeShow called - ready: true
D/BaseAds-Interstitial: Showing interstitial ad
```

### Smart Clickable Events
```
D/BaseAds-Click: Smart click triggered: save_button
D/BaseAds-Click: Click action completed: save_button
D/BaseAds-Button: Button clicked: Save Settings
D/BaseAds-Button: Post-button-click interstitial attempt - shown: true
```

### Search Analytics
```
D/BaseAds-Search: Search triggered: query='test query'
D/BaseAds-Keyboard: Search triggered via keyboard: query='test query'
D/BaseAds-Search: Search completed successfully
```

### Analytics Events
```
D/BaseAds-Analytics: Event logged: button_click
D/BaseAds-Analytics: Event logged: search_performed
D/BaseAds-Analytics: Event logged: click_ad_attempt
```

## 🔍 Debugging Tips

1. **Filter Logcat by "BaseAds"** to see all library logs
2. **Check ads loading status** - look for "ready: true/false"
3. **Verify config values** - showInterstitialBeforeNavigate, etc.
4. **Monitor analytics events** - ensure tracking is working
5. **Watch for error messages** - all exceptions are logged

## 📱 Testing Checklist

- [ ] Banner ads show immediately after app start
- [ ] Interstitial ads appear after button clicks  
- [ ] Search analytics are logged properly
- [ ] VIP status affects ad display
- [ ] Error handling works correctly
- [ ] Analytics events are fired

## ⚠️ Important Notes

- **DO NOT use in production** - this has debug overhead
- **Large file size** - includes debug symbols
- **Verbose logging** - may impact performance
- **Use release AAR** for production builds

---

**For production:** Use `./build-aar.sh` instead  
**For debugging:** This file is perfect! 🐛
